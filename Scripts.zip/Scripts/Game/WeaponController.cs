﻿using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

namespace Unity.FPS.Game
{
    public enum WeaponShootType
    {
        Manual,
        Automatic,
        Charge,
    }

    [System.Serializable]
    public struct CrosshairData
    {
        [Tooltip("この武器のクロスヘアとして使用される画像")]
        public Sprite CrosshairSprite;

        [Tooltip("クロスヘア画像のサイズ")]
        public int CrosshairSize;

        [Tooltip("クロスヘア画像の色")]
        public Color CrosshairColor;
    }

    [RequireComponent(typeof(AudioSource))]
    public class WeaponController : MonoBehaviour
    {
        [Header("情報")]
        [Tooltip("この武器のUIで表示される名前")]
        public string WeaponName;

        [Tooltip("この武器のUIで表示される画像")]
        public Sprite WeaponIcon;

        [Tooltip("クロスヘアのデフォルトデータ")]
        public CrosshairData CrosshairDataDefault;

        [Tooltip("敵をターゲットしているときのクロスヘアデータ")]
        public CrosshairData CrosshairDataTargetInSight;

        [Header("内部参照")]
        [Tooltip("武器のルートオブジェクト。武器がアクティブでないときに非アクティブ化されるオブジェクトです")]
        public GameObject WeaponRoot;

        [Tooltip("武器の先端、弾丸が発射される場所")]
        public Transform WeaponMuzzle;

        [Header("射撃パラメータ")]
        [Tooltip("武器の種類は射撃方法に影響を与えます")]
        public WeaponShootType ShootType;

        [Tooltip("弾丸のプレハブ")]
        public ProjectileBase ProjectilePrefab;

        [Tooltip("二発の間の最小間隔")]
        public float DelayBetweenShots = 0.5f;

        [Tooltip("弾丸がランダムに発射される円錐の角度 (0はまったく拡散しないことを意味します)")]
        public float BulletSpreadAngle = 0f;

        [Tooltip("エイム時の弾丸がランダムに発射される円錐の角度 (0はまったく拡散しないことを意味します)")]
        public float AimBulletSpreadAngle = 0f;

        [Tooltip("一発あたりの弾丸の数")]
        public int BulletsPerShot = 1;

        [Tooltip("発射後に武器を後退させる力")]
        [Range(0f, 2f)]
        public float RecoilForce = 1;

        [Tooltip("この武器で狙いを定めているときのデフォルトFOV比率")]
        [Range(0f, 1f)]
        public float AimZoomRatio = 1f;

        [Tooltip("狙いを定めるときに武器の腕に適用される移動量")]
        public Vector3 AimOffset;






        [Header("弾薬パラメータ")]
        [Tooltip("プレイヤーが手動でリロードするか")]
        public bool AutomaticReload = true;

        [Tooltip("武器に物理的なクリップがあり、発射時に弾薬シェルが排出される")]
        public bool HasPhysicalBullets = false;

        [Tooltip("クリップ内の弾丸数")]
        public int ClipSize = 30;

        [Tooltip("弾薬シェルのケーシング")]
        public GameObject ShellCasing;

        [Tooltip("物理的な弾薬のための武器の排出口")]
        public Transform EjectionPort;

        [Tooltip("シェルに適用される力")]
        [Range(0.0f, 5.0f)]
        public float ShellCasingEjectionForce = 2.0f;

        [Tooltip("再利用前に生成される最大シェル数")]
        [Range(1, 30)]
        public int ShellPoolSize = 1;

        [Tooltip("1秒あたりのリロード弾薬量")]
        public float AmmoReloadRate = 1f;

        [Tooltip("最後の発射後、リロードを開始するまでの遅延")]
        public float AmmoReloadDelay = 2f;

        [Tooltip("銃の最大弾薬数")]
        public int MaxAmmo = 8;

        [Header("チャージパラメータ (チャージ武器のみ)")]
        [Tooltip("最大チャージに達したときに発射をトリガーする")]
        public bool AutomaticReleaseOnCharged;

        [Tooltip("最大チャージに達するまでの時間")]
        public float MaxChargeDuration = 2f;

        [Tooltip("チャージを開始するときに使用する初期弾薬量")]
        public float AmmoUsedOnStartCharge = 1f;

        [Tooltip("チャージが最大に達したときに使用される追加弾薬量")]
        public float AmmoUsageRateWhileCharging = 1f;

        [Header("オーディオ & ビジュアル")]
        [Tooltip("発射アニメーション用のオプション武器アニメーター")]
        public Animator WeaponAnimator;

        [Tooltip("マズルフラッシュのプレハブ")]
        public GameObject MuzzleFlashPrefab;

        [Tooltip("生成時にマズルフラッシュインスタンスを親から切り離す")]
        public bool UnparentMuzzleFlash;

        [Tooltip("発射時のサウンド")]
        public AudioClip ShootSfx;

        [Tooltip("この武器に切り替えたときのサウンド")]
        public AudioClip ChangeWeaponSfx;

        [Tooltip("連続発射音")]
        public bool UseContinuousShootSound = false;
        public AudioClip ContinuousShootStartSfx;
        public AudioClip ContinuousShootLoopSfx;
        public AudioClip ContinuousShootEndSfx;
        AudioSource m_ContinuousShootAudioSource = null;
        bool m_WantsToShoot = false;
        [Header("状態管理")]
        [Tooltip("現在のエイム状態")]

       

        public UnityAction OnShoot;
        public event Action OnShootProcessed;

        int m_CarriedPhysicalBullets;
        float m_CurrentAmmo;
        float m_LastTimeShot = Mathf.NegativeInfinity;
        public float LastChargeTriggerTimestamp { get; private set; }
        Vector3 m_LastMuzzlePosition;

        public GameObject Owner { get; set; }
        public GameObject SourcePrefab { get; set; }
        public bool IsCharging { get; private set; }
        public float CurrentAmmoRatio { get; private set; }
        public bool IsWeaponActive { get; private set; }
        public bool IsCooling { get; private set; }
        public float CurrentCharge { get; private set; }
        public Vector3 MuzzleWorldVelocity { get; private set; }
        public bool IsAiming { get; private set; } = false;


        public float GetAmmoNeededToShoot() =>
            (ShootType != WeaponShootType.Charge ? 1f : Mathf.Max(1f, AmmoUsedOnStartCharge)) /
            (MaxAmmo * BulletsPerShot);

        public int GetCarriedPhysicalBullets() => m_CarriedPhysicalBullets;
        public int GetCurrentAmmo() => Mathf.FloorToInt(m_CurrentAmmo);

        AudioSource m_ShootAudioSource;

        public bool IsReloading { get; private set; }

        const string k_AnimAttackParameter = "Attack";

        private Queue<Rigidbody> m_PhysicalAmmoPool;

        private InputAction aimAction;

        void Awake()
        {
            m_CurrentAmmo = MaxAmmo;
            m_CarriedPhysicalBullets = HasPhysicalBullets ? ClipSize : 0;
            m_LastMuzzlePosition = WeaponMuzzle.position;

            m_ShootAudioSource = GetComponent<AudioSource>();
            DebugUtility.HandleErrorIfNullGetComponent<AudioSource, WeaponController>(m_ShootAudioSource, this,
                gameObject);

            if (UseContinuousShootSound)
            {
                m_ContinuousShootAudioSource = gameObject.AddComponent<AudioSource>();
                m_ContinuousShootAudioSource.playOnAwake = false;
                m_ContinuousShootAudioSource.clip = ContinuousShootLoopSfx;
                m_ContinuousShootAudioSource.outputAudioMixerGroup =
                    AudioUtility.GetAudioGroup(AudioUtility.AudioGroups.WeaponShoot);
                m_ContinuousShootAudioSource.loop = true;
            }

            if (HasPhysicalBullets)
            {
                m_PhysicalAmmoPool = new Queue<Rigidbody>(ShellPoolSize);

                for (int i = 0; i < ShellPoolSize; i++)
                {
                    GameObject shell = Instantiate(ShellCasing, transform);
                    shell.SetActive(false);
                    m_PhysicalAmmoPool.Enqueue(shell.GetComponent<Rigidbody>());
                }

            }

            //aimAction = new InputAction(type: InputActionType.Button, binding: "<Mouse>/rightButton");
            //aimAction.performed += ctx => SetAiming(true);
            //aimAction.canceled += ctx => SetAiming(false);
            //aimAction.Enable();

            //SetAimingの処理をどうする？
           
        }

        public void AddCarriablePhysicalBullets(int count) => m_CarriedPhysicalBullets = Mathf.Max(m_CarriedPhysicalBullets + count, MaxAmmo);

        void ShootShell()
        {
            Rigidbody nextShell = m_PhysicalAmmoPool.Dequeue();

            nextShell.transform.position = EjectionPort.transform.position;
            nextShell.transform.rotation = EjectionPort.transform.rotation;
            nextShell.gameObject.SetActive(true);
            nextShell.transform.SetParent(null);
            nextShell.collisionDetectionMode = CollisionDetectionMode.Continuous;
            nextShell.AddForce(nextShell.transform.up * ShellCasingEjectionForce, ForceMode.Impulse);

            m_PhysicalAmmoPool.Enqueue(nextShell);
        }

        void PlaySFX(AudioClip sfx) => AudioUtility.CreateSFX(sfx, transform.position, AudioUtility.AudioGroups.WeaponShoot, 0.0f);


        void Reload()
        {
            if (m_CarriedPhysicalBullets > 0)
            {
                m_CurrentAmmo = Mathf.Min(m_CarriedPhysicalBullets, ClipSize);
            }

            IsReloading = false;
        }

        public void StartReloadAnimation()
        {
            if (m_CurrentAmmo < m_CarriedPhysicalBullets)
            {
                GetComponent<Animator>().SetTrigger("Reload");
                IsReloading = true;
            }
        }

        void Update()
        {
            UpdateAmmo();
            UpdateCharge();
            UpdateContinuousShootSound();

            if (Time.deltaTime > 0)
            {
                MuzzleWorldVelocity = (WeaponMuzzle.position - m_LastMuzzlePosition) / Time.deltaTime;
                m_LastMuzzlePosition = WeaponMuzzle.position;
            }

            // エイム切り替え処理 (例: 右クリックでエイム) 
            
        }


        private void SetAiming(bool isAiming)
        {
            IsAiming = isAiming;
            // 必要に応じてエイム時の追加処理を記述
            Debug.Log($"Aiming: {isAiming}");
        }

        //private void OnDestroy()
        //{
        //    aimAction.Disable(); // InputAction を無効化
        //}

        void UpdateAmmo()
        {
            if (AutomaticReload && m_LastTimeShot + AmmoReloadDelay < Time.time && m_CurrentAmmo < MaxAmmo && !IsCharging)
            {
                // reloads weapon over time
                m_CurrentAmmo += AmmoReloadRate * Time.deltaTime;

                // limits ammo to max value
                m_CurrentAmmo = Mathf.Clamp(m_CurrentAmmo, 0, MaxAmmo);

                IsCooling = true;
            }
            else
            {
                IsCooling = false;
            }

            if (MaxAmmo == Mathf.Infinity)
            {
                CurrentAmmoRatio = 1f;
            }
            else
            {
                CurrentAmmoRatio = m_CurrentAmmo / MaxAmmo;
            }
        }

        void UpdateCharge()
        {
            if (IsCharging)
            {
                if (CurrentCharge < 1f)
                {
                    float chargeLeft = 1f - CurrentCharge;

                    // Calculate how much charge ratio to add this frame
                    float chargeAdded = 0f;
                    if (MaxChargeDuration <= 0f)
                    {
                        chargeAdded = chargeLeft;
                    }
                    else
                    {
                        chargeAdded = (1f / MaxChargeDuration) * Time.deltaTime;
                    }

                    chargeAdded = Mathf.Clamp(chargeAdded, 0f, chargeLeft);

                    // See if we can actually add this charge
                    float ammoThisChargeWouldRequire = chargeAdded * AmmoUsageRateWhileCharging;
                    if (ammoThisChargeWouldRequire <= m_CurrentAmmo)
                    {
                        // Use ammo based on charge added
                        UseAmmo(ammoThisChargeWouldRequire);

                        // set current charge ratio
                        CurrentCharge = Mathf.Clamp01(CurrentCharge + chargeAdded);
                    }
                }
            }
        }

        void UpdateContinuousShootSound()
        {
            if (UseContinuousShootSound)
            {
                if (m_WantsToShoot && m_CurrentAmmo >= 1f)
                {
                    if (!m_ContinuousShootAudioSource.isPlaying)
                    {
                        m_ShootAudioSource.PlayOneShot(ShootSfx);
                        m_ShootAudioSource.PlayOneShot(ContinuousShootStartSfx);
                        m_ContinuousShootAudioSource.Play();
                    }
                }
                else if (m_ContinuousShootAudioSource.isPlaying)
                {
                    m_ShootAudioSource.PlayOneShot(ContinuousShootEndSfx);
                    m_ContinuousShootAudioSource.Stop();
                }
            }
        }

        public void ShowWeapon(bool show)
        {
            WeaponRoot.SetActive(show);

            if (show && ChangeWeaponSfx)
            {
                m_ShootAudioSource.PlayOneShot(ChangeWeaponSfx);
            }

            IsWeaponActive = show;
        }

        public void UseAmmo(float amount)
        {
            m_CurrentAmmo = Mathf.Clamp(m_CurrentAmmo - amount, 0f, MaxAmmo);
            m_CarriedPhysicalBullets -= Mathf.RoundToInt(amount);
            m_CarriedPhysicalBullets = Mathf.Clamp(m_CarriedPhysicalBullets, 0, MaxAmmo);
            m_LastTimeShot = Time.time;
        }

        public bool HandleShootInputs(bool inputDown, bool inputHeld, bool inputUp)
        {
            m_WantsToShoot = inputDown || inputHeld;
            switch (ShootType)
            {
                case WeaponShootType.Manual:
                    if (inputDown)
                    {
                        return TryShoot();
                    }

                    return false;

                case WeaponShootType.Automatic:
                    if (inputHeld)
                    {
                        return TryShoot();
                    }

                    return false;

                case WeaponShootType.Charge:
                    if (inputHeld)
                    {
                        TryBeginCharge();
                    }

                    // Check if we released charge or if the weapon shoot autmatically when it's fully charged
                    if (inputUp || (AutomaticReleaseOnCharged && CurrentCharge >= 1f))
                    {
                        return TryReleaseCharge();
                    }

                    return false;

                default:
                    return false;
            }
        }

        bool TryShoot()
        {
            if (m_CurrentAmmo >= 1f
                && m_LastTimeShot + DelayBetweenShots < Time.time)
            {
                HandleShoot();
                m_CurrentAmmo -= 1f;

                return true;
            }

            return false;
        }

        bool TryBeginCharge()
        {
            if (!IsCharging
                && m_CurrentAmmo >= AmmoUsedOnStartCharge
                && Mathf.FloorToInt((m_CurrentAmmo - AmmoUsedOnStartCharge) * BulletsPerShot) > 0
                && m_LastTimeShot + DelayBetweenShots < Time.time)
            {
                UseAmmo(AmmoUsedOnStartCharge);

                LastChargeTriggerTimestamp = Time.time;
                IsCharging = true;

                return true;
            }

            return false;
        }

        bool TryReleaseCharge()
        {
            if (IsCharging)
            {
                HandleShoot();

                CurrentCharge = 0f;
                IsCharging = false;

                return true;
            }

            return false;
        }

        void HandleShoot()
        {
           // int bulletsPerShotFinal = ShootType == WeaponShootType.Charge
             //   ? Mathf.CeilToInt(CurrentCharge * BulletsPerShot)
             //   : BulletsPerShot;

            int bulletsPerShotFinal = BulletsPerShot;

            // 弾丸を発射
            for (int i = 0; i < bulletsPerShotFinal; i++)
            {
                Vector3 shotDirection = GetShotDirectionWithinSpread(WeaponMuzzle);
                ProjectileBase newProjectile = Instantiate(ProjectilePrefab, WeaponMuzzle.position, Quaternion.LookRotation(shotDirection));
                newProjectile.Shoot(this);
            }


            // spawn all bullets with random direction
            for (int i = 0; i < bulletsPerShotFinal; i++)
            {
                Vector3 shotDirection = GetShotDirectionWithinSpread(WeaponMuzzle);
                ProjectileBase newProjectile = Instantiate(ProjectilePrefab, WeaponMuzzle.position,
                    Quaternion.LookRotation(shotDirection));
                newProjectile.Shoot(this);
            }

            // muzzle flash
            if (MuzzleFlashPrefab != null)
            {
                GameObject muzzleFlashInstance = Instantiate(MuzzleFlashPrefab, WeaponMuzzle.position,
                    WeaponMuzzle.rotation, WeaponMuzzle.transform);
                // Unparent the muzzleFlashInstance
                if (UnparentMuzzleFlash)
                {
                    muzzleFlashInstance.transform.SetParent(null);
                }

                Destroy(muzzleFlashInstance, 2f);
            }

            if (HasPhysicalBullets)
            {
                ShootShell();
                m_CarriedPhysicalBullets--;
            }

            m_LastTimeShot = Time.time;

            // play shoot SFX
            if (ShootSfx && !UseContinuousShootSound)
            {
                m_ShootAudioSource.PlayOneShot(ShootSfx);
            }

            // Trigger attack animation if there is any
            if (WeaponAnimator)
            {
                WeaponAnimator.SetTrigger(k_AnimAttackParameter);
            }

            OnShoot?.Invoke();
            OnShootProcessed?.Invoke();
        }

        public Vector3 GetShotDirectionWithinSpread(Transform shootTransform)
        {
            // エイム状態に応じてばらつき角度を切り替え
            float currentSpreadAngle = IsAiming ? AimBulletSpreadAngle : BulletSpreadAngle;

            // ばらつき角度を0〜1の比率に変換
            float spreadAngleRatio = currentSpreadAngle / 180f;

            // ランダムな方向に拡散させる
            Vector3 spreadWorldDirection = Vector3.Slerp(
                shootTransform.forward,
                UnityEngine.Random.insideUnitSphere,
                spreadAngleRatio
            );

            return spreadWorldDirection;
        }
        //public void SetAiming(bool aiming)
        //{
        //    IsAiming = aiming;
        //}

    }
}