﻿using Unity.FPS.Game;
using UnityEngine;
using UnityEngine.InputSystem;


namespace Unity.FPS.Gameplay
{
    public class PlayerInputHandler : MonoBehaviour
    {
        [Tooltip("カメラを動かす際の感度の倍率")]
        public float LookSensitivity = 1f;

        [Tooltip("WebGL用の追加の感度倍率")]
        public float WebglLookSensitivityMultiplier = 0.25f;

        [Tooltip("コントローラーのトリガー入力を考慮するための閾値")]
        public float TriggerAxisThreshold = 0.4f;

        [Tooltip("垂直入力軸を反転するかどうか")]
        public bool InvertYAxis = false;

        [Tooltip("水平入力軸を反転するかどうか")]
        public bool InvertXAxis = false;

        private GameFlowManager m_GameFlowManager;
        private PlayerCharacterController m_PlayerCharacterController;
        private bool m_FireInputWasHeld;

        private PlayerInput m_PlayerInput;

        private InputAction moveAction;
        private InputAction lookAction;
        private InputAction jumpAction;
        private InputAction fireAction;
        private InputAction aimAction;
        private InputAction sprintAction;
        private InputAction crouchAction;
        private InputAction reloadAction;
        private InputAction switchWeaponAction;
        private InputAction selectWeaponAction;

        private InputAction uiClick;

        void Awake()
        {
            m_PlayerInput = GetComponent<PlayerInput>();

            // Assign Input Actions
            moveAction = m_PlayerInput.actions["Move"];
            lookAction = m_PlayerInput.actions["Look"];
            jumpAction = m_PlayerInput.actions["Jump"];
            fireAction = m_PlayerInput.actions["Attack"];
            aimAction = m_PlayerInput.actions["Aim"];
            sprintAction = m_PlayerInput.actions["Sprint"];
            crouchAction = m_PlayerInput.actions["Submit"];
            reloadAction = m_PlayerInput.actions["Reload"];
            switchWeaponAction = m_PlayerInput.actions["SwitchWeapon"];
            selectWeaponAction = m_PlayerInput.actions["SelectWeapon"];

            uiClick = m_PlayerInput.actions["Click"];


        }

        void Start()
        {
            m_PlayerCharacterController = GetComponent<PlayerCharacterController>();
            DebugUtility.HandleErrorIfNullGetComponent<PlayerCharacterController, PlayerInputHandler>(
                m_PlayerCharacterController, this, gameObject);
            m_GameFlowManager = FindObjectOfType<GameFlowManager>();
            DebugUtility.HandleErrorIfNullFindObject<GameFlowManager, PlayerInputHandler>(m_GameFlowManager, this);

            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        void LateUpdate()
        {
            m_FireInputWasHeld = GetFireInputHeld();
        }

        public bool CanProcessInput()
        {
            return Cursor.lockState == CursorLockMode.Locked && !m_GameFlowManager.GameIsEnding;

        }

        public Vector3 GetMoveInput()
        {
            if (CanProcessInput())
            {
                Vector2 move = moveAction.ReadValue<Vector2>();
                return new Vector3(move.x, 0f, move.y);
            }

            return Vector3.zero;
        }

        public float GetLookInputsHorizontal()
        {
            return GetLookAxis(true);
        }

        public float GetLookInputsVertical()
        {
            return GetLookAxis(false);
        }

        public bool GetJumpInputDown()
        {
            return CanProcessInput() && jumpAction.triggered;

        }

        public bool GetJumpInputHeld()
        {
            return CanProcessInput() && jumpAction.triggered;

        }

        public bool GetFireInputDown()
        {
            return GetFireInputHeld() && !m_FireInputWasHeld;
        }

        public bool GetFireInputReleased()
        {
            return !GetFireInputHeld() && m_FireInputWasHeld;
        }

        public bool GetFireInputHeld()
        {
            return CanProcessInput() && fireAction.ReadValue<float>() >= TriggerAxisThreshold;
        }

        public bool GetSprintInputHeld()
        {
            return CanProcessInput() && sprintAction.IsPressed();
        }

        public bool GetCrouchInputDown()
        {
            return CanProcessInput() && crouchAction.triggered;
        }

        public bool GetAimInputHeld()
        {
            return CanProcessInput() && aimAction.IsPressed(); 
        }

        public bool GetReloadButtonDown()
        {
            return CanProcessInput() && reloadAction.triggered;

        }

        public int GetSwitchWeaponInput()
        {
            if (CanProcessInput())
            {
                // Get the vertical scroll value (y-axis)
                float value = switchWeaponAction.ReadValue<Vector2>().y;

                // Determine the direction of scrolling
                if (value > 0f) return 1;   // Scroll up (switch to next weapon)
                if (value < 0f) return -1;  // Scroll down (switch to previous weapon)
            }
            return 0;  // No input
        }

        public int GetSelectWeaponInput()
        {
            if (CanProcessInput())
            {
                for (int i = 1; i <= 9; i++)
                {
                    if (selectWeaponAction.ReadValue<int>() == i)
                        return i;
                }
            }
            return 0;
        }

        private float GetLookAxis(bool isHorizontal)
        {
            if (CanProcessInput())
            {
                Vector2 look = lookAction.ReadValue<Vector2>();
                float axis = isHorizontal ? look.x : look.y;

                if (isHorizontal && InvertXAxis || !isHorizontal && InvertYAxis)
                    axis *= -1f;

                axis *= LookSensitivity;
#if UNITY_WEBGL
                    axis *= WebglLookSensitivityMultiplier;
#endif
                return axis;
            }

            return 0f;
        }
    }
}


