﻿using Unity.FPS.Game;
using UnityEngine;
using System.Collections;
using UnityEngine.UI;

namespace Unity.FPS.Gameplay
{
    public class ObjectiveKillEnemies : Objective
    {
        [Tooltip("すべての敵を倒す必要があるか、最小限の数だけ倒せばよいかを選択します")]
        public bool MustKillAllEnemies = true;

        [Tooltip("MustKillAllEnemiesがfalseの場合、目標達成に必要な敵のキル数")]
        public int KillsToCompleteObjective = 5;

        [Tooltip("この数の敵が残ったときに、残りの敵についての通知を送信し始めます")]
        public int NotificationEnemiesRemainingThreshold = 3;

        [Tooltip("目標達成までのタイマー（秒単位）")]
        public float ObjectiveTimer = 600f; // 10分（600秒）

        [Tooltip("残り時間を表示するUIテキスト")]
        public Text TimerText;

        int m_KillTotal;
        bool m_TimerStarted = false;
        float m_RemainingTime;

        protected override void Start()
        {
            base.Start();

            // 敵が倒された際のイベントリスナーを追加
            EventManager.AddListener<EnemyKillEvent>(OnEnemyKilled);

            // このタイプの目標に特定のタイトルと説明が設定されていなければ設定
            if (string.IsNullOrEmpty(Title))
                Title = "敵を" + (MustKillAllEnemies ? "全滅させる" : KillsToCompleteObjective.ToString() + "体倒す");

            if (string.IsNullOrEmpty(Description))
                Description = GetUpdatedCounterAmount();

            // タイマーを初期化
            m_RemainingTime = ObjectiveTimer;

            // タイマーをスタート
            StartCoroutine(StartObjectiveTimer());
        }

        IEnumerator StartObjectiveTimer()
        {
            m_TimerStarted = true;

            while (m_RemainingTime > 0)
            {
                // 残り時間を減らす
                m_RemainingTime -= Time.deltaTime;

                // 残り時間がゼロ未満にならないようにする
                if (m_RemainingTime < 0)
                    m_RemainingTime = 0;

                // 残り時間をテキストとして表示
                UpdateTimerText();

                yield return null;
            }

            // タイマーが終了したら目標を達成
            if (!IsCompleted)
            {
                CompleteObjective(string.Empty, GetUpdatedCounterAmount(), "目標達成 : " + Title);
            }
        }

        void UpdateTimerText()
        {
            if (TimerText != null)
            {
                int minutes = Mathf.FloorToInt(m_RemainingTime / 60);
                int seconds = Mathf.FloorToInt(m_RemainingTime % 60);
                TimerText.text = $"Time: {minutes:D2}:{seconds:D2}";
            }
        }

        void OnEnemyKilled(EnemyKillEvent evt)
        {
            // 目標が既に完了している場合は何もしない
            if (IsCompleted)
                return;

            m_KillTotal++;

            // すべての敵を倒す目標の場合、残りの敵の数に基づいて必要なキル数を更新
            if (MustKillAllEnemies)
                KillsToCompleteObjective = evt.RemainingEnemyCount + m_KillTotal;

            int targetRemaining = MustKillAllEnemies ? evt.RemainingEnemyCount : KillsToCompleteObjective - m_KillTotal;

            // 残りの敵数に応じて目標テキストを更新
            if (targetRemaining == 0)
            {
                CompleteObjective(string.Empty, GetUpdatedCounterAmount(), "目標達成 : " + Title);
            }
            else if (targetRemaining == 1)
            {
                // 残り1体の通知テキストを作成
                string notificationText = NotificationEnemiesRemainingThreshold >= targetRemaining
                    ? "残り1体の敵"
                    : string.Empty;
                UpdateObjective(string.Empty, GetUpdatedCounterAmount(), notificationText);
            }
            else
            {
                // 必要であれば通知テキストを作成（空のままなら通知は作成されない）
                string notificationText = NotificationEnemiesRemainingThreshold >= targetRemaining
                    ? "残り" + targetRemaining + "体の敵を倒す"
                    : string.Empty;

                UpdateObjective(string.Empty, GetUpdatedCounterAmount(), notificationText);
            }
        }

        string GetUpdatedCounterAmount()
        {
            return m_KillTotal + " / " + KillsToCompleteObjective;
        }

        void OnDestroy()
        {
            // 敵が倒された際のイベントリスナーを削除
            EventManager.RemoveListener<EnemyKillEvent>(OnEnemyKilled);
        }
    }
}