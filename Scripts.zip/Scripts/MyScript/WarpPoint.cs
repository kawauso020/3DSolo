using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

public class WarpPoint : MonoBehaviour
{// ���[�v���Transform��ݒ�
    [SerializeField] private Transform warpDestination;

    private void OnTriggerEnter(Collider other)
    {
        // ���[�v�\�ȏ������m�F�i�K�v�Ȃ�ǉ��j
        if (warpDestination != null && other.attachedRigidbody != null)
        {
            // �I�u�W�F�N�g�����[�v��Ɉړ�
            other.transform.position = warpDestination.position;

            // ��]���ύX�������ꍇ
            // other.transform.rotation = warpDestination.rotation;

            Debug.Log($"{other.name} was warped to {warpDestination.position}");
        }
        Debug.Log($"{other.name} entered the trigger zone");

        if (warpDestination != null && other.attachedRigidbody != null)
        {
            other.transform.position = warpDestination.position;
            Debug.Log($"{other.name} was warped to {warpDestination.position}");
        }
        else
        {
            Debug.Log("Warp failed: Missing warp destination or rigidbody.");
        }
    }
}
