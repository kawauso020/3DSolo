using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


/// <summary>
/// 
/// </summary>
public class ButtonHandler : MonoBehaviour
{
    private Button myButton;

    void Start()
    {
        if (myButton != null)
        {
            myButton.onClick.AddListener(OnButtonClicked);
        }
    }

    void OnButtonClicked()
    {
        Debug.Log("Button Clicked!");
    }
}
