using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class QuitGameHandler : MonoBehaviour
{
    public void QuitGame()
    {
#if UNITY_EDITOR
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }

    void Update()
    {
        bool escPressed = Keyboard.current?.escapeKey.wasPressedThisFrame ?? false;
        bool startPressed = Gamepad.current?.startButton.wasPressedThisFrame ?? false;

        if (escPressed || startPressed)
        {
            QuitGame();
        }
    }
}