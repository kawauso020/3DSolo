using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class we : MonoBehaviour
{
    [Header("����ݒ�")]
    [Tooltip("���̕��킪���˂���e�ۂ̃v���n�u")]
    public GameObject projectilePrefab;

    [Tooltip("�e�ۂ����������n�_")]
    public Transform projectileSpawnPoint;

    [Tooltip("���ˑ��x (�������ː�)")]
    public float fireRate = 600f;

    [Tooltip("���킪�ێ��ł���ő�e��")]
    public int maxAmmo = 30;

    [Tooltip("���݂̒e��")]
    public int currentAmmo;

    [Tooltip("���ˎ��ɍĐ�����T�E���h")]
    public AudioClip fireSound;

    private float lastTimeFired;
    private AudioSource audioSource;

    private void Awake()
    {
        audioSource = GetComponent<AudioSource>();
        currentAmmo = maxAmmo; // Initialize with full ammo
    }

    public bool CanShoot()
    {
        return currentAmmo > 0 && Time.time > lastTimeFired + 60f / fireRate;
    }

    public void Shoot()
    {
        if (!CanShoot())
            return;

        // Spawn projectile
        GameObject projectile = Instantiate(projectilePrefab, projectileSpawnPoint.position, projectileSpawnPoint.rotation);
        Rigidbody rb = projectile.GetComponent<Rigidbody>();
        if (rb)
        {
            rb.velocity = projectileSpawnPoint.forward * 50f; // Example projectile speed
        }

        // Reduce ammo
        currentAmmo--;

        // Play fire sound
        if (fireSound && audioSource)
        {
            audioSource.PlayOneShot(fireSound);
        }

        lastTimeFired = Time.time;

        // Optional: Destroy the projectile after a delay
        Destroy(projectile, 5f);
    }

    public void Reload()
    {
        currentAmmo = maxAmmo;
    }
}
