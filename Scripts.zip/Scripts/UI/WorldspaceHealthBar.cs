﻿using Unity.FPS.Game;
using UnityEngine;
using UnityEngine.UI;

namespace Unity.FPS.UI
{
    public class WorldspaceHealthBar : MonoBehaviour
    {
        [Tooltip("追跡するヘルスコンポーネント")]
        public Health Health;

        [Tooltip("残りのヘルスを表示するイメージコンポーネント")]
        public Image HealthBarImage;

        [Tooltip("浮かぶヘルスバーのピボットトランスフォーム")]
        public Transform HealthBarPivot;

        [Tooltip("ヘルスが満タンのときにヘルスバーを非表示にするかどうか")]
        public bool HideFullHealthBar = true;

        void Update()
        {
            // update health bar value
            HealthBarImage.fillAmount = Health.CurrentHealth / Health.MaxHealth;

            // rotate health bar to face the camera/player
            HealthBarPivot.LookAt(Camera.main.transform.position);

            // hide health bar if needed
            if (HideFullHealthBar)
                HealthBarPivot.gameObject.SetActive(HealthBarImage.fillAmount != 1);
        }
    }
}