﻿using Unity.FPS.Game;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;
using UnityEngine.InputSystem;

namespace Unity.FPS.UI
{
    public class LoadSceneButton : MonoBehaviour
    {
        public string SceneName = "";
        private PlayerInput playerInput;

        void Start()
        {
            playerInput = GetComponent<PlayerInput>();

            if (playerInput == null)
            {
                Debug.LogError("PlayerInput コンポーネントがこのオブジェクトにアタッチされていません！");
                return;
            }

            // UI アクションマップに切り替え
            playerInput.SwitchCurrentActionMap("UI");

            Debug.Log("Current Action Map: " + playerInput.currentActionMap.name);

            // **アクション一覧を出力**
            foreach (var action in playerInput.currentActionMap.actions)
            {
                Debug.Log($"Action Name: {action.name}, Path: {action.bindings}");
            }
        }

        void Update()
        {
            if (playerInput.actions["Submit"].triggered)
            {
                LoadTargetScene();
            }
        }

        public void LoadTargetScene()
        {
            SceneManager.LoadScene(SceneName);
        }
    }
}