﻿using UnityEngine;
using UnityEngine.UI;

namespace Unity.FPS.UI
{
    public class FillBarColorChange : MonoBehaviour
    {
        [Header("前景")]
        [Tooltip("前景のイメージ")]
        public Image ForegroundImage;

        [Tooltip("デフォルトの前景色")]
        public Color DefaultForegroundColor;

        [Tooltip("満杯時に前景が点滅する色")]
        public Color FlashForegroundColorFull;

        [Header("背景")]
        [Tooltip("背景のイメージ")]
        public Image BackgroundImage;

        [Tooltip("空の状態で背景が点滅する色")]
        public Color DefaultBackgroundColor;

        [Tooltip("色の変化のシャープさ")]
        public Color FlashBackgroundColorEmpty;

        [Header("値")]
        [Tooltip("満杯と見なす値")]
        public float FullValue = 1f;

        [Tooltip("空と見なす値")]
        public float EmptyValue = 0f;

        [Tooltip("色の変化のシャープさ")]
        public float ColorChangeSharpness = 5f;
        float m_PreviousValue;

        public void Initialize(float fullValueRatio, float emptyValueRatio)
        {
            FullValue = fullValueRatio;
            EmptyValue = emptyValueRatio;

            m_PreviousValue = fullValueRatio;
        }

        public void UpdateVisual(float currentRatio)
        {
            if (currentRatio == FullValue && currentRatio != m_PreviousValue)
            {
                ForegroundImage.color = FlashForegroundColorFull;
            }
            else if (currentRatio < EmptyValue)
            {
                BackgroundImage.color = FlashBackgroundColorEmpty;
            }
            else
            {
                ForegroundImage.color = Color.Lerp(ForegroundImage.color, DefaultForegroundColor,
                    Time.deltaTime * ColorChangeSharpness);
                BackgroundImage.color = Color.Lerp(BackgroundImage.color, DefaultBackgroundColor,
                    Time.deltaTime * ColorChangeSharpness);
            }

            m_PreviousValue = currentRatio;
        }
    }
}