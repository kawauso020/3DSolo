﻿using UnityEngine;

namespace Unity.FPS.UI
{
    public class DisplayMessage : MonoBehaviour
    {
        //[Tooltip("表示されるテキスト")] [TextArea]
        //public string message;
        //
        //[Tooltip("メッセージのプレハブ")] public GameObject messagePrefab;
        //
        //[Tooltip("メッセージが表示されるまでの遅延時間")]
        //public float delayBeforeShowing;
        //
        //float m_InitTime = float.NegativeInfinity; // 初期化時の時間
        //bool m_WasDisplayed; // メッセージが表示されたかどうか
        //DisplayMessageManager m_DisplayMessageManager; // メッセージ表示用のマネージャー
        //
        //void Start()
        //{
        //    m_InitTime = Time.time; // スクリプト開始時の時間を保存
        //    m_DisplayMessageManager = FindObjectOfType<DisplayMessageManager>(); // DisplayMessageManagerを検索して取得
        //    DebugUtility.HandleErrorIfNullFindObject<DisplayMessageManager, DisplayMessage>(m_DisplayMessageManager,
        //        this); // DisplayMessageManagerが見つからなかった場合のエラーハンドリング
        //}
        //
        // Updateは毎フレーム呼び出されます
        //void Update()
        //{
        //    if (m_WasDisplayed) // 既にメッセージが表示されている場合は処理を終了
        //        return;
        //
        //    if (Time.time - m_InitTime > delayBeforeShowing) // 指定された遅延時間が経過した場合
        //    {
        //        var messageInstance = Instantiate(messagePrefab, m_DisplayMessageManager.DisplayMessageRect); // メッセージのプレハブをインスタンス化
        //        var notification = messageInstance.GetComponent<NotificationToast>(); // NotificationToastコンポーネントを取得
        //        if (notification)
        //        {
        //            notification.Initialize(message); // メッセージを初期化
        //        }
        //
        //        m_WasDisplayed = true; // メッセージが表示されたことを記録
        //    }
        //}
    }
}