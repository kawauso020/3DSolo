using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyMove : MonoBehaviour
{
    private NavMeshAgent agent;
    private Transform target;

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();

        // "EnemyTarget"�^�O�����I�u�W�F�N�g��T���ă^�[�Q�b�g�ɐݒ�
        GameObject targetObject = GameObject.FindGameObjectWithTag("EnemyTarget");
        if (targetObject != null)
        {
            target = targetObject.transform;
        }
        else
        {
            Debug.LogWarning("Target with tag 'EnemyTarget' not found!");
        }
    }

    void Update()
    {
        if (target != null)
        {
            agent.SetDestination(target.position);  // �^�[�Q�b�g�Ɍ������Ĉړ�
        }
    }
}
